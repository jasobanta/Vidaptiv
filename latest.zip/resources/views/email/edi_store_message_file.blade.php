Date: {{$data['date']}}<br/>
File name name: {{$data['file_name']}} <br/>
EDI sent by: {{$data['user']['email']}} <br/>
{{$data['message']}} <br/> 