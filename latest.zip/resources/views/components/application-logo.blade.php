<img src="{{ asset('img/image-removebg-preview-16-1.png') }}"
     srcset="img/image-removebg-preview-16-1@2x.png 2x,
     img/image-removebg-preview-16-1@3x.png 3x"
     class="image-removebg-preview-16-1">
