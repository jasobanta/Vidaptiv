<div>
    {!! nl2br($email_body) !!}
    <div>
        <div><br/><br/><br/>
            {!! nl2br($signature) !!}
        </div>