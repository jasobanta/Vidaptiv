<?php

return [
    'routes' => [
        'dashboard',
        'dashboard/ajax',
        'show-file',
        'logout',
        'show-file-action',
        'diff-download'
    ],
    'links' => [
        'dashboard'
    ],
];
